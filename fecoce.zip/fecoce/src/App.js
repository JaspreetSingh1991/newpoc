import {
  AppBar,
  Box,
  Button,
  createTheme,
  Grid2,
  Tab,
  Tabs,
  Toolbar,
} from '@mui/material';
import './App.css';

import { DataGrid } from '@mui/x-data-grid';
import { ThemeProvider } from '@emotion/react';
import { useEffect, useState } from 'react';
import { getTasksList, triggerDag, updateTasks } from './services/tasks';
import { useNavigate } from 'react-router-dom';

const columns = [
  { field: 'scriptId', headerName: 'Script ID', width: 200 },
  { field: 'scriptCmd', headerName: 'Script Command', width: 230 },
  { field: 'createdBy', headerName: 'Created By', width: 230 },
  {
    field: 'status',
    headerName: 'Status',
    width: 230,
  },
];

const darkTheme = createTheme({
  palette: {
    background: {
      default: '#303030',
    },
    text: {
      primary: '#ffffff',
    },
  },
});

function appBarLabel(rowSelectionModel, selectedTab, tasks, fetchTaskList, approverSelectionModel) {
  const sendForApproval = () => {
    let tasksSelected = tasks.maker?.filter(
      (task) => rowSelectionModel.indexOf(task.id) !== -1
    );
    const payload = tasksSelected.map((task) => {
      const modfiedTask = {
        approvedStatus: true,
        scriptId: task.scriptId,
        isRun: task.isRun,
        approvedBy: 0
      };
      return modfiedTask;
    });

    updateTasks(payload).then((resp) => {
      if (resp?.data) {
        alert('Record updated successfully!!');
        fetchTaskList();
      } else {
        alert('Some error occurred!!');
      }
    })
  };

  const runDag = () => {
    triggerDag().then((resp) => {
      if (resp) {
        alert('Record updated successfully!!');
        fetchTaskList();
      } else {
        alert('Dag run failed!!')
      }
    })
      .catch(() => {
        alert('Dag run failed!!')
      })
  }

  const approveTasks = () => {
    let tasksSelected = tasks?.approver?.filter(
      (task) => approverSelectionModel.indexOf(task.id) !== -1
    );
    const payload = tasksSelected.map((task) => {
      const modfiedTask = {
        approvedStatus: true,
        scriptId: task.scriptId,
        isRun: 'active',
        approvedBy: JSON.parse(sessionStorage.getItem('userInfo'))?.userId
      };
      return modfiedTask;
    });
    updateTasks(payload).then((resp) => {
      if (resp?.data) {
        runDag()
      } else {
        alert('DB update error!!');
      }
    })
      .catch(() => {
        alert('DB update error')
      })
  };
  return (
    <Toolbar
      sx={{
        backgroundColor: 'white',
        color: 'black',
        borderBottom: '1px solid black',
      }}
    >
      <Grid2 container spacing={4}>
        <Grid2 item xs={2}>
          <Button
            sx={{ color: 'black', borderColor: 'black' }}
            variant="outlined"
            onClick={sendForApproval}
            disabled={selectedTab !== 0 || rowSelectionModel.length === 0}
          >
            Run
          </Button>
        </Grid2>
        <Grid2 item xs={2}>
          <Button
            sx={{ color: 'black', borderColor: 'black' }}
            variant="outlined"
            onClick={approveTasks}
            disabled={selectedTab !== 1 || approverSelectionModel.length === 0}
          >
            Approve
          </Button>
        </Grid2>
      </Grid2>
    </Toolbar>
  );
}

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

function App() {
  const [rowSelectionModel, setRowSelectionModel] = useState([]);
  const [approverSelectionModel, setApproverSelectionModel] = useState([]);
  const [value, setValue] = useState(1);
  const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
  const [tasks, setTasks] = useState({ maker: [], approver: [] });
  const navigate = useNavigate();

  useEffect(() => {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    const defaultTab =
      userInfo?.userType === 1 ? 0 : userInfo?.userType === 2 ? 1 : 0;
    setValue(defaultTab);
    // getTasksList().then((data)=>{
    //   console.log(data)
    // })
    const timer = setInterval(() => {
      fetchTaskList();
    }, 8000);
    fetchTaskList();
    return () => clearInterval(timer);
  }, []);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const fetchTaskList = () => {
    const userId = JSON.parse(sessionStorage.getItem('userInfo'))?.userId;
    if (userId == null) {
      navigate('/');
    } else {
      getTasksList(userId).then((resp) => {
        let tasks = resp?.data;
        const makerTasks = tasks?.maker?.map((task) => {
          task.status =
            task.approvedStatus === true && task.isRun === 'active'
              ? task.runStatus !== '' ? task.runStatus : 'Running'
              : task.approvedStatus === true && task.isRun !== 'active'
                ? 'Pending Approval'
                : 'New';
          task.id = task.scriptId;
          return task;
        });
        const approverTasks = tasks?.approver?.map((task) => {
          task.status =
            task.approvedStatus === true && task.isRun === 'active'
              ? task.runStatus !== '' ? task.runStatus : 'Running'
              : task.approvedStatus === true && task.isRun !== 'active'
                ? 'Pending Approval'
                : 'New';
          task.id = task.scriptId;
          return task;
        });
        setTasks({ maker: makerTasks, approver: approverTasks });
      })
    }
  };

  return (
    <div className="App">
      <header className="App-header">NSE Tasks List</header>
      <ThemeProvider theme={darkTheme}>
        <AppBar position="static" color="primary">
          {appBarLabel(rowSelectionModel, value, tasks, fetchTaskList, approverSelectionModel)}
        </AppBar>
      </ThemeProvider>
      <Box
        sx={{ borderBottom: 1, borderColor: 'divider', paddingLeft: '10px' }}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          textColor="black"
          TabIndicatorProps={{ style: { background: 'black', color: 'black' } }}
        >
          {(userInfo?.userType === 1 || userInfo?.userType === 3) && (
            <Tab label="Maker" {...a11yProps(0)} />
          )}
          {(userInfo?.userType === 2 || userInfo?.userType === 3) && (
            <Tab label="Checker" {...a11yProps(1)} />
          )}
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
        <DataGrid
          rows={tasks.maker}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 20 },
            },
          }}
          pageSizeOptions={[5, 10]}
          checkboxSelection
          onRowSelectionModelChange={(newRowSelectionModel) => {
            setRowSelectionModel(newRowSelectionModel);
          }}
          rowSelectionModel={rowSelectionModel}
          sx={{ overflow: 'clip' }}
        />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        <DataGrid
          rows={tasks.approver}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 20 },
            },
          }}
          pageSizeOptions={[5, 10]}
          checkboxSelection
          onRowSelectionModelChange={(newRowSelectionModel) => {
            setApproverSelectionModel(newRowSelectionModel);
          }}
          rowSelectionModel={approverSelectionModel}
          sx={{ overflow: 'clip' }}
        />
      </CustomTabPanel>
    </div>
  );
}

export default App;
