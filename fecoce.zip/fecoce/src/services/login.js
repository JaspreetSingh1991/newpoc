import axios from 'axios';

const login = (userId) => {
  return axios.get(`http://localhost:8090/api/v1/getUser/`+userId);
};

export { login };
