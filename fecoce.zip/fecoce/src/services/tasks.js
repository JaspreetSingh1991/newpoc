import axios from 'axios';

const getTasksList = (userId) => {
  return axios.get(`http://localhost:8090/api/v1/getScriptDetails/` + userId);
  // const data = {
  //   maker:[{
  //     scriptId: 0,
  //     scriptCmd: '/wjhjhf/kjw',
  //     createdBy: 'Test',
  //     isApproved: false,
  //     isRun: false
  //   },
  //   {
  //     scriptId: 1,
  //     scriptCmd: '/wjhjhf/kjw',
  //     createdBy: 'Test1',
  //     isApproved: true,
  //     isRun: false
  //   },
  //   {
  //     scriptId: 2,
  //     scriptCmd: '/wjhjhf/kjw',
  //     createdBy: 'Test2',
  //     isApproved: true,
  //     isRun: true
  //   }],
  //   approver: [
  //     {
  //       scriptId: 3,
  //       scriptCmd: '/wjhjhf/kjw',
  //       createdBy: 'Test3',
  //       isApproved: true,
  //       isRun: false
  //     }
  //   ]
  // }
};


const updateTasks = (payload) => {
  return axios.put(`http://localhost:8090/api/v1/updateScriptDetails/`, [...payload]);
};

const runTasks = () => {
  const body = {
    "dag_run_id": "manual__" + new Date().getTime()
  }
  const token = 'YWlyZmxvdzphaXJmbG93'
  return axios.put(`http://localhost:8080/api/v1/dags/checker_bash_tasks_dag/dagRuns`, body, {
    headers: {
      'Authorization': `Basic ${token}`,
      'Content-Type': `application/json`
    }
  });
};

const triggerDag = () => {
  return axios.post(`http://localhost:8090/api/v1/triggerDag/`, {});
};

export { getTasksList, updateTasks, runTasks, triggerDag };
