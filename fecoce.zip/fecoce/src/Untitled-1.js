if (resp?.data === true) {
        runTasks().then((resp2)=>{
          alert('Record updated successfully!!');
          fetchTaskList();
        })
        .catch(()=>{
          alert('Some error occurred!!');
        })
        
      }